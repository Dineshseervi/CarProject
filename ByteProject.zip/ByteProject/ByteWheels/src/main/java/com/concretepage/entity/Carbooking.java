package com.concretepage.entity;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="carbooking")
@NamedQueries(value = { @NamedQuery(name = "Carbooking.findByDate", query = "select s.carId,count(s.carId) from Carbooking s where (s.startDate >=:startDate and s.endDate<=:endDate) or (s.startDate <=:startDate and s.endDate>=:startDate)  or  (s.startDate =:endDate or s.endDate=:startDate )  GROUP BY s.carId") }
)
public class Carbooking implements Serializable { 
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="booking_id")
    private int bookingId;  
	
	@Column(name="car_id")
    private int carId;  
	
	@Column(name="emailId")
    private String emailId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="StartDate")	
	private Date startDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="EndDate")	
	private Date endDate;
	
	@Column(name="TotalCost")
    private String totalCost;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}

	@Override
	public String toString() {
		return "Carbooking [bookingId=" + bookingId + ", carId=" + carId + ", emailId=" + emailId + ", startDate="
				+ startDate + ", endDate=" + endDate + ", totalCost=" + totalCost + "]";
	}
	
	
	
} 