package com.concretepage.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.concretepage.entity.BookingDetails;
import com.concretepage.entity.BookingModel;
import com.concretepage.entity.Carbooking;
import com.concretepage.entity.Cars;
import com.concretepage.service.ICarService;
import com.concretepage.util.RentCarException;
import com.google.gson.Gson;

@Controller
@RequestMapping("/rent")
public class RentCarController {
	@Autowired
	private ICarService carService;

	private static final Logger LOGGER = LoggerFactory.getLogger(RentCarController.class);

	private static final SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
	private static final DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

	/*
	 * This method is used to get All cars details from ByteWheels
	 */
	@GetMapping("/car")
	public ResponseEntity<Object> getAllCars() {
		try {
			LOGGER.info("getAllCars is called");
			List<Cars> carList = carService.getAllCars();
			if (carList != null && !carList.isEmpty()) {
				return new ResponseEntity<Object>(carList, HttpStatus.OK);
			} else {
				return new ResponseEntity<Object>("No Cars available", HttpStatus.OK);
			}
		} catch (Exception e) {
			LOGGER.error("error inside getAllCars {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}

	}

	/*
	 * This method is used to get cars details from ByteWheels by Category
	 * param=category read step 4
	 */
	@GetMapping("/car/category")
	public ResponseEntity<Object> getCarsByCategory(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		try {
			LOGGER.info("getCarsByCategory is called");
			String category = httpServletRequest.getParameter("category");
			if (category == null || category.equals("")) {
				throw new RentCarException("Category can't be null");
			}
			List<Cars> carList = carService.getCarsByCategory(category);
			if (carList != null && !carList.isEmpty()) {
				return new ResponseEntity<Object>(carList, HttpStatus.OK);
			} else {
				return new ResponseEntity<Object>("No Cars available", HttpStatus.OK);
			}
		} catch (Exception e) {
			LOGGER.error("getCarsByCategory error {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}

	}

	/*
	 * This method is used to get available cars details from ByteWheels for
	 * given Dates if available param=startDate and endDate read step 4
	 */
	@GetMapping("/car/date")
	public ResponseEntity<Object> getAvailableCars(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		try {
			LOGGER.info("getAvailableCars is called");
			String startDate = httpServletRequest.getParameter("startDate");
			String endDate = httpServletRequest.getParameter("endDate");
			LOGGER.debug("getAvailableCars startDate {} ,endDate {}", startDate, endDate);
			if (startDate == null || startDate.equals("") || endDate == null || endDate.equals("")) {
				throw new RentCarException("StartDate Or EndDatte can't be null");
			}
			Date sDate = sf.parse(startDate);
			Date eDate = sf.parse(endDate);
			if (sDate == null || eDate == null) {
				throw new RentCarException("Date formate excpetion");
			}
			if (sDate.compareTo(eDate) > 0) {
				throw new RentCarException("StartDate can't be after EndDate");
			}
			Collection<Cars> carList = carService.availableCars(sDate, eDate);
			if (carList != null && !carList.isEmpty()) {
				return new ResponseEntity<Object>(carList, HttpStatus.OK);
			} else {
				return new ResponseEntity<Object>("No Cars available", HttpStatus.OK);
			}
		} catch (Exception e) {
			LOGGER.error("getAvailableCars error {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}

	}

	/*
	 * To Start the booking of selected Car and Dates user need to give his
	 * emailId for sending Email.
	 * 
	 * Type:POST read step 4
	 */
	@PostMapping("/car/bookcar")
	public ResponseEntity<Object> setOtpForCarBooking(@RequestBody String bookingJson,
			HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) {
		try {
			LOGGER.info("setOtpForCarBooking is called");
			BookingDetails bookingDetails = new BookingDetails();
			Gson gson = new Gson();
			bookingDetails = gson.fromJson(bookingJson, BookingDetails.class);
			LOGGER.debug("setOtpForCarBooking  bookingDetails : {}", bookingDetails);
			if (bookingDetails == null || bookingDetails.getEmailId().equals("")) {
				throw new RentCarException("EmailID Cant be null");
			} else if (bookingDetails.getCarId() == null) {
				throw new RentCarException("CarId Cant be null");
			}
			boolean result = carService.sendEmailForConfirmation(bookingDetails);
			if (result) {
				return new ResponseEntity<Object>("OTP has been send", HttpStatus.OK);
			} else {
				return new ResponseEntity<Object>("Error While sending OTP", HttpStatus.OK);
			}
		} catch (Exception e) {
			LOGGER.error("setOtpForCarBooking error : {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}

	}

	/*
	 * POST method for confirming the Booking by Validating OTP recived on
	 * EmailID
	 * 
	 * Type:POST read step 4
	 */
	@PostMapping("/car/booking/otp")
	public ResponseEntity<Object> otpValidation(@RequestBody String bookingJson, HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse) {
		BookingModel bookingModel = null;
		try {
			LOGGER.info("otpValidation is called");
			BookingDetails bookingDetails = new BookingDetails();
			Gson gson = new Gson();
			bookingDetails = gson.fromJson(bookingJson, BookingDetails.class);
			LOGGER.debug("otpValidation bookingDetails {}", bookingDetails);
			if (bookingDetails == null || bookingDetails.getEmailId().equals("")) {
				throw new RentCarException("EmailID Cant be null");
			} else if (bookingDetails.getOtp() == null) {
				throw new RentCarException("OTP Cant be null");
			}
			Carbooking carbooking = carService.otpValidationForBookingConf(bookingDetails.getEmailId(),
					bookingDetails.getOtp());
			bookingModel = new BookingModel();
			bookingModel.setBookingId(carbooking.getBookingId());
			bookingModel.setEmailId(carbooking.getEmailId());
			bookingModel.setCarId(carbooking.getCarId());
			bookingModel.setStartDate(dateFormat.format(carbooking.getStartDate()));
			bookingModel.setEndDate(dateFormat.format(carbooking.getEndDate()));
			bookingModel.setTotalCost(carbooking.getTotalCost());

		} catch (Exception e) {
			LOGGER.error("otpValidation error {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}
		return new ResponseEntity<Object>(bookingModel, HttpStatus.OK);
	}

	@GetMapping("/car/booking/")
	public ResponseEntity<Object> getBookingDetails() {
		List<Carbooking> carList = carService.getCarBookingDetails();
		if (carList != null && !carList.isEmpty()) {
			List<BookingModel> bookingDetails = new ArrayList<>();
			for (Carbooking carbooking : carList) {
				BookingModel bookingModel = new BookingModel();
				bookingModel.setBookingId(carbooking.getBookingId());
				bookingModel.setEmailId(carbooking.getEmailId());
				bookingModel.setCarId(carbooking.getCarId());
				bookingModel.setStartDate(dateFormat.format(carbooking.getStartDate()));
				bookingModel.setEndDate(dateFormat.format(carbooking.getEndDate()));
				bookingModel.setTotalCost(carbooking.getTotalCost());

				bookingDetails.add(bookingModel);
			}
			return new ResponseEntity<Object>(bookingDetails, HttpStatus.OK);
		} else {
			return new ResponseEntity<Object>("No Cars available", HttpStatus.OK);
		}

	}

	/*
	 * To Get bookingDetails for given bookingId.
	 */
	@GetMapping("car/booking/{id}")
	public ResponseEntity<Object> getArticleById(@PathVariable("id") Integer bookingId) {
		try {

			LOGGER.info("getArticleById is called");
			Carbooking carbooking = carService.getBookingDetlById(bookingId);
			LOGGER.debug("getArticleById ID: {} ", bookingId);
			if (carbooking == null) {
				throw new RentCarException("No booking data found for given BookingId");
			}
			BookingModel bookingModel = new BookingModel();
			bookingModel.setBookingId(carbooking.getBookingId());
			bookingModel.setEmailId(carbooking.getEmailId());
			bookingModel.setCarId(carbooking.getCarId());
			bookingModel.setStartDate(dateFormat.format(carbooking.getStartDate()));
			bookingModel.setEndDate(dateFormat.format(carbooking.getEndDate()));
			bookingModel.setTotalCost(carbooking.getTotalCost());
			return new ResponseEntity<Object>(bookingModel, HttpStatus.OK);

		} catch (Exception e) {
			LOGGER.error("getArticleById error {}", e.getMessage());
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.OK);
		}
	}
}