package com.concretepage.entity;

public class BookingModel {
	
	private String emailId;
	private int bookingId;
	private Integer carId;
	private String startDate;
	private String endDate;
	private String totalCost;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	public String getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	@Override
	public String toString() {
		return "BookingModel [emailId=" + emailId + ", bookingId=" + bookingId + ", carId=" + carId + ", startDate="
				+ startDate + ", endDate=" + endDate + ", totalCost=" + totalCost + "]";
	}
	
	
	
	
}
