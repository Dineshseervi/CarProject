package com.concretepage.dao;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.concretepage.entity.Carbooking;
import com.concretepage.entity.Cars;
@Transactional
@Repository
public class CarsDAO implements ICarDAO {
	@PersistenceContext	
	private EntityManager entityManager;	
	
	@Autowired
	private CarBookingRepository carBookingRepository;
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Cars> getAllCars() {
		
		String hql = "FROM Cars as cs ORDER BY cs.carID";
		return (List<Cars>) entityManager.createQuery(hql).getResultList();
	}
	@Override
	public List<Cars> getCarsByCategory(String category) {
		String hql = "FROM Cars as cs WHERE  cs.category = ?";
		return entityManager.createQuery(hql).setParameter(1, category)
		              .getResultList();
	}
	@Override
	public List<Object[]> availableCars(Date startDate, Date endDate) {
		return entityManager.createNamedQuery("Carbooking.findByDate").setParameter("startDate", startDate, TemporalType.DATE).setParameter("endDate", endDate, TemporalType.DATE).getResultList();
		
	}
	@Override
	public Carbooking addCarBooking(Carbooking carbooking) {
		return carBookingRepository.save(carbooking);
	}
	@Override
	public List<Carbooking> getCarBookingDetails() {
		String hql = "FROM Carbooking as cb ORDER BY cb.bookingId";
		return (List<Carbooking>) entityManager.createQuery(hql).getResultList();
		
	}
	
	@Override
	public Carbooking getBookingDetailsById(int bookingId) {
		return entityManager.find(Carbooking.class, bookingId);
	}
}
