package com.concretepage.entity;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="cars")
public class Cars implements Serializable { 
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="car_id")
    private int carID;  
	@Column(name="name")
    private String name;
	@Column(name="category")	
	private String category;
	@Column(name="quantity")	
	private Integer quantity;
	@Column(name="car_cost")	
	private String carcost;
	
	public String getCarcost() {
		return carcost;
	}
	public void setCarcost(String carcost) {
		this.carcost = carcost;
	}
	public int getCarID() {
		return carID;
	}
	public void setCarID(int carID) {
		this.carID = carID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Cars [carID=" + carID + ", name=" + name + ", category=" + category + ", quantity=" + quantity
				+ ", carcost=" + carcost + "]";
	}
		
	
	
} 