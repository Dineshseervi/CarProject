package com.concretepage.entity;

public class BookingDetails {

	private String emailId;
	private Integer carId;
	private String startDate;
	private String endDate;
	private String otp;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getCarId() {
		return carId;
	}
	public void setCarId(Integer carId) {
		this.carId = carId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	@Override
	public String toString() {
		return "BookingDetails [emailId=" + emailId + ", carId=" + carId + ", startDate=" + startDate + ", endDate="
				+ endDate + ", otp=" + otp + "]";
	}
	
	
	
	
	
	
}
