package com.concretepage.util;

public class RentCarException extends Exception{

	public RentCarException(String message) {
		super(message);
		
	}

	
}
