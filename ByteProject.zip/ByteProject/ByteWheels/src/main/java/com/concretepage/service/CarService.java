package com.concretepage.service;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.concretepage.dao.ICarDAO;
import com.concretepage.entity.BookingDetails;
import com.concretepage.entity.Carbooking;
import com.concretepage.entity.Cars;
import com.concretepage.util.Communication;
import com.concretepage.util.RentCarException;

@Service
public class CarService implements ICarService {

	@Autowired
	private ICarDAO carDAO;

	@Autowired
	private Communication communication;

	private static final SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
	public static Map<String, Cars> carsMap = null;
	public static Map<String, BookingDetails> bookingMap = new HashMap<>();

	private void loadProperty() {
		if (carsMap == null) {
			synchronized (this) {
				if (carsMap == null) {
					carsMap = new HashMap<>();
					getAllCars().forEach(c -> carsMap.put(String.valueOf(c.getCarID()), c));
				}
			}

		}
	}

	@Override
	public List<Cars> getAllCars() {
		return carDAO.getAllCars();
	}

	@Override
	public List<Cars> getCarsByCategory(String category) {
		return carDAO.getCarsByCategory(category);
	}

	@Override
	public Collection<Cars> availableCars(Date startDate, Date endDate) {
		loadProperty();
		Map<String, Cars> myCarsMap = new HashMap<>();
		Map<String, Integer> bookingCount = new HashMap<>();
		List<Object[]> carPreBooked = carDAO.availableCars(startDate, endDate);

		for (Object[] carBooked : carPreBooked) {
			String carId = carBooked[0].toString();
			Integer count = Integer.parseInt(carBooked[1].toString());
			bookingCount.put(carId, count);
		}

		for (Entry<String, Cars> carObject : carsMap.entrySet()) {
			if (bookingCount.containsKey(carObject.getKey())) {
				int bookedCount = bookingCount.get(carObject.getKey());
				int totalCount = carObject.getValue().getQuantity();
				int available = totalCount - bookedCount;
				if (available > 0) {
					Cars cars = carObject.getValue();
					cars.setQuantity(available);
					myCarsMap.put(carObject.getKey(), cars);
				}
			} else {
				myCarsMap.put(carObject.getKey(), carObject.getValue());
			}
		}
		return myCarsMap.values();
	}
/*
 * This  method generate OTP for given length
 */
	public String generateOtp() {

		int len = 6;
		String number = "0123456789";
		Random rdm = new Random();
		StringBuffer otp = new StringBuffer();
		for (int i = 0; i < len; i++) {
			otp.append(number.charAt(rdm.nextInt(number.length())));
		}
		return otp.toString();

	}

	@Override
	public List<Carbooking> getCarBookingDetails() {
		return carDAO.getCarBookingDetails();
	}

	/*
	 *This method send OTP to User for booking.
	 *And store the booking details object for OTP validation in a hashMap .
	 * 
	 * (non-Javadoc)
	 * @see com.concretepage.service.ICarService#sendEmailForConfirmation(com.concretepage.entity.BookingDetails)
	 */
	@Override
	public boolean sendEmailForConfirmation(BookingDetails bookingDetails) {
		loadProperty();
		String otp = generateOtp();
		System.out.println("OTP " + otp);
		bookingDetails.setOtp(otp);
		bookingMap.put(bookingDetails.getEmailId(), bookingDetails);
		return communication.sendMail(bookingDetails.getEmailId(), otp, "localhost:8080/car/bookcar");
	}

	/*
	 * 
	 * This method validate OTP  for confirmation of booking,From user
	 * Once booking is done bookingObject is removed from HashMap,and  store the data in Carbooking Table 
	 * (non-Javadoc)
	 * @see com.concretepage.service.ICarService#otpValidationForBookingConf(java.lang.String, java.lang.String)
	 */
	@Override
	public Carbooking otpValidationForBookingConf(String emailId, String otp) throws Exception {
		Carbooking carbooking = new Carbooking();
		if (!bookingMap.containsKey(emailId)) {
			throw new RentCarException("There is no Booking request for this email-Id");
		}
		BookingDetails bookingDetails = bookingMap.get(emailId);
		if (!bookingDetails.getOtp().equals(otp)) {
			throw new RentCarException("OTP is invalid");
		} else {
			Integer carId = bookingDetails.getCarId();
			carbooking.setCarId(carId);
			carbooking.setEmailId(emailId);
			Date sDate = sf.parse(bookingDetails.getStartDate());
			Date eDate = sf.parse(bookingDetails.getEndDate());
			carbooking.setStartDate(sDate);
			carbooking.setEndDate(eDate);
			Double cost = Double.parseDouble(carsMap.get(carId.toString()).getCarcost());
			int days = Days.daysBetween(new LocalDate(sDate.getTime()), new LocalDate(eDate.getTime())).getDays() + 1;
			Double totalCost = days * cost;
			carbooking.setTotalCost(totalCost.toString());
			carbooking = carDAO.addCarBooking(carbooking);
		}
		bookingMap.remove(emailId);
		return carbooking;
	}

	@Override
	public Carbooking getBookingDetlById(int bookingId) {
		Carbooking obj = carDAO.getBookingDetailsById(bookingId);
		return obj;
	}
}
