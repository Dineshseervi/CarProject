package com.concretepage.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.concretepage.entity.Article;
import com.concretepage.entity.BookingDetails;
import com.concretepage.entity.Carbooking;
import com.concretepage.entity.Cars;
import com.concretepage.util.RentCarException;

public interface ICarService {
	List<Cars> getAllCars();
    List<Cars> getCarsByCategory(String category);
    Collection<Cars> availableCars(Date startDate,Date endDate);
    //Carbooking addCarBooking(Carbooking category);
    List<Carbooking> getCarBookingDetails();
    boolean sendEmailForConfirmation(BookingDetails bookingDetails);
    Carbooking otpValidationForBookingConf(String emailId,String otp) throws Exception;
	
	Carbooking getBookingDetlById(int bookingId);
}
