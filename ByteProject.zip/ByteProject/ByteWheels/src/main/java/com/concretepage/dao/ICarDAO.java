package com.concretepage.dao;
import java.util.Date;
import java.util.List;

import com.concretepage.entity.Article;
import com.concretepage.entity.Carbooking;
import com.concretepage.entity.Cars;
public interface ICarDAO {
    List<Cars> getAllCars();
    List<Cars> getCarsByCategory(String category);
    List<Object []> availableCars(Date startDate,Date endDate);
    Carbooking addCarBooking(Carbooking carbooking);
    List<Carbooking> getCarBookingDetails();
    Carbooking getBookingDetailsById(int bookingId);
    
}
 